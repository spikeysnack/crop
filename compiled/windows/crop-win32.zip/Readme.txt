crop.exe

To Install,

Copy all files in this  directory to C:\Program Files (x86)\crop\ . 

Then, to make crop accessible from all dirs,
copy crop.exe and cygwin1.dll to the C:\Windows directory.

crop.cmd is a clickable file that launches a dos window
into the crop directory.

